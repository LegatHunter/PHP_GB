<?php

$fileContents = file_get_contents('file.txt');
echo $fileContents;
