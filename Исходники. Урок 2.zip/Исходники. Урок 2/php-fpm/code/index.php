<?php

echo "Привет, GeekBrains!<br>".date("Y-m-d H:i:s") ."<br><br>";

echo "Что-то еще";

phpinfo();