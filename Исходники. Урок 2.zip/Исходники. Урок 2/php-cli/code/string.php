<?php

$str = "Hello world";

$stringArray = explode(" ", $str);

echo $str[0];

var_dump($stringArray);