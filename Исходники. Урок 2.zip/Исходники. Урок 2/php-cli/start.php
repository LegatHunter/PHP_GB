<?php

echo "Привет, GeekBrains!";

// docker run --rm -v ${pwd}/php-cli/:/cli php:8.2-cli php /cli/start.php