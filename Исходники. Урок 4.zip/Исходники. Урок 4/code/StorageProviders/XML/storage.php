<?php

namespace StoradeProviders\XML;

class Storage {
}
